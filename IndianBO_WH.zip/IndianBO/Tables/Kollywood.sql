CREATE TABLE [IndianBO].[Kollywood] (

	[FilmID] varchar(8000) NULL, 
	[Title] varchar(8000) NULL, 
	[Release_Date] varchar(8000) NULL, 
	[DirectorID] varchar(8000) NULL, 
	[Lead_Actor_Actress] varchar(8000) NULL, 
	[LanguageID] varchar(8000) NULL, 
	[Industry] varchar(8000) NULL, 
	[GenreID] varchar(8000) NULL, 
	[Budget] varchar(8000) NULL, 
	[First_Day_Collection_Worldwide] varchar(8000) NULL, 
	[Worldwide_Collection_in_Crores] varchar(8000) NULL, 
	[Overseas_Collection] varchar(8000) NULL, 
	[India_Gross_Collection] varchar(8000) NULL, 
	[Verdict] varchar(8000) NULL, 
	[IMDb_Rating] varchar(8000) NULL, 
	[Runtime_mins] varchar(8000) NULL, 
	[OTT_Platform] varchar(8000) NULL, 
	[Year] varchar(8000) NULL, 
	[Month] varchar(8000) NULL, 
	[Month_Name] varchar(8000) NULL, 
	[Week_Name] varchar(8000) NULL
);