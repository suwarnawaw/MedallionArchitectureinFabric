CREATE TABLE [Movies].[Kollywood] (

	[FilmID] int NULL, 
	[Title] varchar(8000) NULL, 
	[Release_Date] datetime2(6) NULL, 
	[DirectorID] int NULL, 
	[Lead_Actor_Actress] varchar(8000) NULL, 
	[LanguageID] int NULL, 
	[Industry] varchar(8000) NULL, 
	[GenreID] int NULL, 
	[Budget] float NULL, 
	[First_Day_Collection_Worldwide] float NULL, 
	[Worldwide_Collection_in_Crores] float NULL, 
	[Overseas_Collection] float NULL, 
	[India_Gross_Collection] float NULL, 
	[Verdict] varchar(8000) NULL, 
	[IMDb_Rating] float NULL, 
	[Runtime_mins] int NULL, 
	[OTT_Platform] varchar(8000) NULL, 
	[Year] int NULL, 
	[Month] int NULL, 
	[Month_Name] varchar(8000) NULL, 
	[Week_Name] varchar(8000) NULL
);